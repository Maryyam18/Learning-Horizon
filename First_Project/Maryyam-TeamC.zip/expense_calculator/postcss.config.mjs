export default {
plugins: {
"@tailwindcss/postcss": {},
}
}